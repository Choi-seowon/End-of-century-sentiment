firebase.initializeApp(firebaseConfig);
database = firebase.database();

function sendMsg() {
    let date = new Date();
    let msg = $(".message").val();
    database.ref("msgs/" + date.getTime()).set(msg);
    $(".message").val("");
}

function loadMsgs() {
    database.ref("msgs").on("value", callback);
    function callback(snapshot) {
        $(".chat").html("");
        console.log(snapshot);
        snapshot.forEach(function (child) {
            $(".chat").append("<div>" + child.val() + "</div>");
        });
        $(".chat").scrollTop(15000);
    }
}

$(document).ready(() => {
    loadMsgs();

    $(".btn").on("click", () => {
        sendMsg();
    });

    $(".message").keyDown((key) => {
        if (key.keyCode == 13) {
            sendMsg()
        };
    })
});
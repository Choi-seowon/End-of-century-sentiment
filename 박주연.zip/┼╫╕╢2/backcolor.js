const btnTheme1 = document.getElementById("button-1");
const btnTheme2 = document.getElementById("button-2");
const btnTheme3 = document.getElementById("button-3");
const btnTheme4 = document.getElementById("button-4");
const chattop = document.getElementById("top_c");
const themetop = document.getElementById("top_t");

btnTheme1.addEventListener("click", (e) => {
    document.body.style.backgroundImage = "url('icon/back1.png')";
    chattop.style.background = "linear-gradient(180deg, #79b3e9 0%, rgba(136, 113, 255, 0.99) 145%)";
    themetop.style.background = "linear-gradient(180deg, #79b3e9 0%, rgba(136, 113, 255, 0.99) 145%)";
});

btnTheme2.addEventListener("click", (e) => {
    document.body.style.backgroundImage = "url('icon/back2.png')";
    chattop.style.background = "linear-gradient(180deg, #f0ff80 0%, rgba(255, 183, 125, 0.99) 145%)";
    themetop.style.background = "linear-gradient(180deg, #f0ff80 0%, rgba(255, 183, 125, 0.99) 145%)";
});

btnTheme3.addEventListener("click", (e) => {
    document.body.style.backgroundImage = "url('icon/back3.png')";
    chattop.style.background = "linear-gradient(180deg, #FFBBE4 0%, rgba(255, 32, 166, 0.99) 145%)";
    themetop.style.background = "linear-gradient(180deg, #FFBBE4 0%, rgba(255, 32, 166, 0.99) 145%)";
});

btnTheme4.addEventListener("click", (e) => {
    document.body.style.backgroundImage = "url('icon/back4.png')";
    chattop.style.background = "linear-gradient(180deg, #f0ff80 0%, rgba(255, 183, 125, 0.99) 145%)";
    themetop.style.background = "linear-gradient(180deg, #f0ff80 0%, rgba(255, 183, 125, 0.99) 145%)";
});